const Koa = require("koa");

const app = new Koa();

app.use((ctx) => {
  ctx.body = "OK";
});

module.exports = app;
